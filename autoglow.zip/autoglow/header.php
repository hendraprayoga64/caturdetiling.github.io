<!DOCTYPE html>
<html lang="en">
<head>
	<!-- set the encoding of your site -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- set the page title -->
	<title>Autoglow - Car Washing Service & Auto Detail HTML Template</title>
	<!-- inlcude google nunito sans font cdn link -->
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<!-- inlcude google nunito sans font cdn link -->
	<link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:ital,wght@0,300;0,400;0,600;0,700;1,300;1,400;1,600;1,700&display=swap" rel="stylesheet">
	<!-- inlcude google fira sans font cdn link -->
	<link href="https://fonts.googleapis.com/css2?family=Fira+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">
	<!-- include the site bootstrap stylesheet -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- include the site stylesheet -->
	<link rel="stylesheet" href="style.css">
	<!-- include theme color setting stylesheet -->
	<link rel="stylesheet" href="css/colors.css">
	<!-- include the site responsive stylesheet -->
	<link rel="stylesheet" href="css/responsive.css">
</head>
<body>
	<!-- pageWrapper -->
	<div id="pageWrapper">
		<!-- phStickyWrap -->
		<div class="phStickyWrap">
			<div class="headerFixer">
				<!-- pageHeader -->
				<header id="pageHeader" class="bg-white">
					<div class="container-fluid clearfix">
						<div class="logo">
							<a href="home1.html">
								<img src="images/catur.png" class="img-fluid" alt="Autoglow Carwash" style="max-width: 50%; margin-left: 28%;">
							</a>
						</div>
						<nav id="pageNav" class="navbar navbar-expand-lg navbar-light justify-content-end justify-content-lg-start position-static">
							<div class="collapse navbar-collapse pageMainNavCollapse" id="pageMainNavCollapse">
								<ul class="navbar-nav mainNavigation fontAlter fwMedium pl-lg-3 pl-xlwd-9 pl-xxl-18">
									<li class="nav-item dropdown ddohOpener">
										<a class="nav-link dropdown-toggle" href="javascript:void(0);" id="homeDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Home</a>
										<!-- dropdown-menu / hdMainDropdown / desktopDropOnHover -->
										<div class="dropdown-menu hdMainDropdown desktopDropOnHover">
											<ul class="list-unstyled mb-0 hdDropdownList">
												<li><a class="dropdown-item" href="home1.html">Home 1</a></li>
												<li><a class="dropdown-item" href="home2.html">Home 2</a></li>
											</ul>
										</div>
									</li>
									<li class="nav-item dropdown ddohOpener">
										<a class="nav-link dropdown-toggle" href="javascript:void(0);" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Pages</a>
										<!-- dropdown-menu / hdMainDropdown / desktopDropOnHover -->
										<div class="dropdown-menu hdMainDropdown desktopDropOnHover">
											<ul class="list-unstyled mb-0 hdDropdownList">
												<li><a class="dropdown-item" href="404Error.html">404 Error</a></li>
												<li><a class="dropdown-item" href="about.html">About</a></li>
												<li><a class="dropdown-item" href="bookingSystem.html">Booking System</a></li>
												<li><a class="dropdown-item" href="faq.html">FAQ</a></li>
												<li><a class="dropdown-item" href="myAccount.html">My Account</a></li>
												<li><a class="dropdown-item" href="pricingPackage.html">Pricing Package</a></li>
												<li><a class="dropdown-item" href="team.html">Team</a></li>
												<li><a class="dropdown-item" href="teamSingle.html">Team Single</a></li>
												<li><a class="dropdown-item" href="testimonials.html">Testimonials</a></li>
												<li><a class="dropdown-item" href="elements.html">Elements</a></li>
												<li><a class="dropdown-item" href="typography.html">Typography</a></li>
											</ul>
										</div>
									</li>
									<li class="nav-item dropdown ddohOpener">
										<a class="nav-link dropdown-toggle" href="javascript:void(0);" id="servicesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Services</a>
										<!-- dropdown-menu / hdMainDropdown / desktopDropOnHover -->
										<div class="dropdown-menu hdMainDropdown desktopDropOnHover">
											<ul class="list-unstyled mb-0 hdDropdownList">
												<li><a class="dropdown-item" href="services.html">Services</a></li>
												<li><a class="dropdown-item" href="servicesSingle.html">Services Single</a></li>
											</ul>
										</div>
									</li>
									<li class="nav-item dropdown ddohOpener">
										<a class="nav-link dropdown-toggle" href="javascript:void(0);" id="portfolioDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Portfolio</a>
										<!-- dropdown-menu / hdMainDropdown / desktopDropOnHover -->
										<div class="dropdown-menu hdMainDropdown desktopDropOnHover">
											<ul class="list-unstyled mb-0 hdDropdownList">
												<li><a class="dropdown-item" href="portfolioGrid.html">Portfolio Grid</a></li>
												<li><a class="dropdown-item" href="portfolioGridCaption.html">Portfolio Grid Caption</a></li>
												<li><a class="dropdown-item" href="portfolioImageGallery.html">Portfolio Image Gallery</a></li>
												<li class="dropdown-submenu">
													<a href="javascript:void(0);" class="dropdown-item dropdown-toggle dropIcn" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Portfolio Single</a>
													<div class="dropdown-menu hdMainDropdown desktopDropOnHover">
														<ul class="list-unstyled mb-0 hdDropdownList">
															<li><a class="dropdown-item" href="portfolioSingle1.html">Portfolio Single 1</a></li>
															<li><a class="dropdown-item" href="portfolioSingle2.html">Portfolio Single 2</a></li>
														</ul>
													</div>
												</li>
											</ul>
										</div>
									</li>
									<li class="nav-item dropdown ddohOpener">
										<a class="nav-link dropdown-toggle" href="javascript:void(0);" id="newsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">News</a>
										<!-- dropdown-menu / hdMainDropdown / desktopDropOnHover -->
										<div class="dropdown-menu hdMainDropdown desktopDropOnHover">
											<ul class="list-unstyled mb-0 hdDropdownList">
												<li><a class="dropdown-item" href="blogClassic.html">News Classic</a></li>
												<li><a class="dropdown-item" href="blogMasonry.html">News Masonry</a></li>
												<li><a class="dropdown-item" href="blogGrid.html">News Grid</a></li>
												<li><a class="dropdown-item" href="blogSinglePost.html">News Single Post</a></li>
											</ul>
										</div>
									</li>
									<li class="nav-item dropdown ddohOpener">
										<a class="nav-link dropdown-toggle" href="javascript:void(0);" id="shopDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Shop</a>
										<!-- dropdown-menu / hdMainDropdown / desktopDropOnHover -->
										<div class="dropdown-menu hdMainDropdown desktopDropOnHover">
											<ul class="list-unstyled mb-0 hdDropdownList">
												<li><a class="dropdown-item" href="shop.html">Shop</a></li>
												<li><a class="dropdown-item" href="singleProduct.html">Single Product</a></li>
												<li><a class="dropdown-item" href="cart.html">Cart</a></li>
												<li><a class="dropdown-item" href="checkout.html">Checkout</a></li>
											</ul>
										</div>
									</li>
									<li class="nav-item">
										<a class="nav-link" href="contact.html">Contact</a>
									</li>
								</ul>
							</div>
							<div class="hdActionsWrap flex-shrink-0 d-flex justify-content-end align-items-center">
								<a href="tel:6507329369" class="btnHdLink fontAlter fwMedium d-none d-xl-inline">
									<i class="icomoon-whatsapp icn"><span class="sr-only">icon</span></i>
									650-732-9369
								</a>
								<ul class="list-unstyled d-flex align-items-center userActionsList mb-0 ml-xl-3 ml-xxl-7">
									<li>
										<a href="myAccount.html" class="ncCartBtn">
											<i class="lnr lnr-user"><span class="sr-only">icon</span></i>
										</a>
									</li>
									<li>
										<a href="cart.html" class="ncCartBtn">
											<i class="lnr lnr-cart"><span class="sr-only">icon</span></i>
										</a>
									</li>
									<li>
										<form class="navSearchForm">
											<a class="navbarSearchOpener" data-toggle="collapse" href="#navbarSearchCollapse" role="button" aria-expanded="false" aria-controls="navbarSearchCollapse">
												<i class="lnr lnr-magnifier"><span class="sr-only">icon</span></i>
											</a>
											<div class="collapse navbarSearchCollapse position-fixed text-white" id="navbarSearchCollapse">
												<div class="d-flex w-100 h-100 align-items-center">
													<div class="align w-100 py-4">
														<div class="container d-block">
															<div class="row">
																<div class="col-12 col-md-10 offset-md-1">
																	<p>Search your query here&hellip;</p>
																	<div class="input-group">
																		<input class="form-control" type="search" placeholder="Search" aria-label="Search">
																		<div class="input-group-append">
																			<button class="btn btnThemeAlt btnNoOver" type="submit">
																				<i class="lnr lnr-magnifier"><span class="sr-only">search</span></i>
																			</button>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
												<a class="navbarSearchClose position-fixed" data-toggle="collapse" href="#navbarSearchCollapse" role="button" aria-expanded="false" aria-controls="navbarSearchCollapse">
													<i class="lnr lnr-cross"><span class="sr-only">icon</span></i>
												</a>
											</div>
										</form>
									</li>
								</ul>
								<button class="navbar-toggler pgNaveOpener border-0 ml-3 position-relative" type="button" data-toggle="collapse" data-target="#pageMainNavCollapse" aria-controls="pageMainNavCollapse" aria-expanded="false" aria-label="Toggle navigation">
									<span class="navbar-toggler-icon"></span>
								</button>
								<a href="bookingSystem.html" class="btn btnThemeAlt border-0 p-0 ml-lg-3 ml-xxl-6 btnHd" data-hover="Book Appointment">
									<span class="d-block btnText">Book Appointment</span>
								</a>
							</div>
						</nav>
					</div>
				</header>
			</div>
		</div>